package com.example.epon_java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MemberLogin extends AppCompatActivity implements View.OnClickListener {
   /* changes
    EditText UsernameEt, PasswordEt;
    /* changes */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_login);
        /* changes
        UsernameEt = (EditText)findViewById(R.id.etUserName);
        PasswordEt = (EditText)findViewById(R.id.etPassword);
         changes */

        TextView textView7 = findViewById(R.id.textView7);
        ImageView imageView = findViewById(R.id.imageView);
        Button btnLogin =findViewById(R.id.btnLogin);

        textView7.setOnClickListener(this);
        imageView.setOnClickListener(this);
        btnLogin.setOnClickListener(this);


    }
    /* changes
    public void onLogin(View view){
        String username = UsernameEt.getText().toString();
        String password = PasswordEt.getText().toString();
        String type = "login";

        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type, username, password);
    }
     changes */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.textView7:
                Toast.makeText(this, "Registration Page", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MemberLogin.this,Registration.class);
                startActivity(intent);
        }
        switch (v.getId()){
            case R.id.imageView:
                Toast.makeText(this, "Landing Page", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MemberLogin.this,MainActivity.class);
                startActivity(intent);

        }
        switch (v.getId()){
            case R.id.btnLogin:
                Toast.makeText(this, "Dashboard", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MemberLogin.this,Dashboard.class);
                startActivity(intent);
        }
    }
}