package com.example.epon_java;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Registration extends AppCompatActivity implements View.OnClickListener {

    TextInputLayout gender;
    AutoCompleteTextView act_gender;
    EditText birthdate;

    DatePickerDialog.OnDateSetListener onDateSetListener;

    ArrayList<String> arrayList_gender;
    ArrayAdapter<String> arrayAdapter_gender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);


        birthdate = findViewById(R.id.date);

        birthdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        Registration.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        onDateSetListener, year, month, day);
              datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.show();



            }
        });

        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month+1;
                String date = dayOfMonth+" / "+month+" / "+year;
                birthdate.setText(date);

            }

        };


        gender = (TextInputLayout) findViewById(R.id.gender);
        act_gender = (AutoCompleteTextView) findViewById(R.id.act_gender);

        arrayList_gender = new ArrayList<>();
        arrayList_gender.add("Male");
        arrayList_gender.add("Female");

        arrayAdapter_gender = new ArrayAdapter<>(getApplicationContext(),R.layout.tv_entity,arrayList_gender);
        act_gender.setAdapter((arrayAdapter_gender));


        Button register = findViewById(R.id.register);
        TextView textView7 = findViewById(R.id.textView7);
        ImageView imageView = findViewById(R.id.imageView);

        register.setOnClickListener(this);
        textView7.setOnClickListener(this);
        imageView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.textView7:
                Toast.makeText(this, "Login Page", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Registration.this,MemberLogin.class);
                startActivity(intent);
        }
        switch (v.getId()){
            case R.id.register:
                Toast.makeText(this, "Registration Success", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Registration.this,MemberLogin.class);
                startActivity(intent);

        }
        switch (v.getId()){
            case R.id.imageView:
                Toast.makeText(this, "Landing Page", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Registration.this,MainActivity.class);
                startActivity(intent);
        }

    }

    public void onRadioButtonClick(View view) {
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
        Toast.makeText(this, "Member Type selected", Toast.LENGTH_SHORT).show();

    }
}